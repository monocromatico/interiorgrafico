﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'ko', {
	IdInputLabel: 'ID',
	advisoryTitleInputLabel: 'Advisory Title',
	cssClassInputLabel: 'Stylesheet Classes',
	edit: 'Edit Div', // MISSING
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: '왼쪽에서 오른쪽 (LTR)',
	langDirLabel: '쓰기 방향',
	langDirRTLLabel: '오른쪽에서 왼쪽 (RTL)',
	languageCodeInputLabel: ' Language Code', // MISSING
	remove: 'Remove Div', // MISSING
	styleSelectLabel: 'Style',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
});
