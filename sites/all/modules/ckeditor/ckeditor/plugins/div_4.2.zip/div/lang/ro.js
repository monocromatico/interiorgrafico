﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'ro', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Titlul consultativ',
	cssClassInputLabel: 'Clasele cu stilul paginii (CSS)',
	edit: 'Edit Div', // MISSING
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: 'stânga-dreapta (LTR)',
	langDirLabel: 'Direcţia cuvintelor',
	langDirRTLLabel: 'dreapta-stânga (RTL)',
	languageCodeInputLabel: 'Codul limbii',
	remove: 'Remove Div', // MISSING
	styleSelectLabel: 'Stil',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
});
