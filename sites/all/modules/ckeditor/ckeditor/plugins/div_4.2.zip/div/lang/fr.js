﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'fr', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Advisory Title',
	cssClassInputLabel: 'Classe CSS',
	edit: 'Éditer la DIV',
	inlineStyleInputLabel: 'Style en ligne',
	langDirLTRLabel: 'Gauche à droite (LTR)',
	langDirLabel: 'Sens d\'écriture',
	langDirRTLLabel: 'Droite à gauche (RTL)',
	languageCodeInputLabel: 'Code de langue',
	remove: 'Enlever la DIV',
	styleSelectLabel: 'Style',
	title: 'Créer un container DIV',
	toolbar: 'Créer un container DIV'
});
