﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'fo', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Advisory Title',
	cssClassInputLabel: 'Stylesheet Classes',
	edit: 'Redigera Div',
	inlineStyleInputLabel: 'Inline Style',
	langDirLTRLabel: 'Vinstru til høgru (LTR)',
	langDirLabel: 'Language Direction',
	langDirRTLLabel: 'Høgru til vinstru (RTL)',
	languageCodeInputLabel: ' Language Code',
	remove: 'Strika Div',
	styleSelectLabel: 'Style',
	title: 'Ger Div Container',
	toolbar: 'Ger Div Container'
});
