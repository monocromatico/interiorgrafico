﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'bg', {
	IdInputLabel: 'ID',
	advisoryTitleInputLabel: 'Препоръчително заглавие',
	cssClassInputLabel: 'Класове за CSS',
	edit: 'Промяна на Div',
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: 'Ляво на Дясно (ЛнД)',
	langDirLabel: 'Посока на езика',
	langDirRTLLabel: 'Дясно на Ляво (ДнЛ)',
	languageCodeInputLabel: ' Код на езика',
	remove: 'Премахване на Div',
	styleSelectLabel: 'Стил',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
});
