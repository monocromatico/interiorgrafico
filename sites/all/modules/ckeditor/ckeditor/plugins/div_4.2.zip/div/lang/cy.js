﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'cy', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Teitl Cynghorol',
	cssClassInputLabel: 'Dosbarthiadau Ffeil Ddiwyg',
	edit: 'Golygu Div',
	inlineStyleInputLabel: 'Arddull Mewn Llinell',
	langDirLTRLabel: 'Chwith i\'r Dde (LTR)',
	langDirLabel: 'Cyfeiriad yr Iaith',
	langDirRTLLabel: 'Dde i\'r Chwith (RTL)',
	languageCodeInputLabel: ' Cod Iaith',
	remove: 'Tynnu Div',
	styleSelectLabel: 'Arddull',
	title: 'Creu Cynhwysydd Div',
	toolbar: 'Creu Cynhwysydd Div'
});
