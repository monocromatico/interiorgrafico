﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'el', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Ενδεικτικός Τίτλος',
	cssClassInputLabel: 'Stylesheet Classes',
	edit: 'Επεξεργασία Div',
	inlineStyleInputLabel: 'Στυλ Εν Σειρά',
	langDirLTRLabel: 'Αριστερά προς Δεξιά (LTR)',
	langDirLabel: 'Κατεύθυνση Κειμένου',
	langDirRTLLabel: 'Δεξιά προς Αριστερά (RTL)',
	languageCodeInputLabel: 'Κωδικός Γλώσσας',
	remove: 'Διαγραφή Div',
	styleSelectLabel: 'Μορφή',
	title: 'Δημιουργεία Div',
	toolbar: 'Δημιουργεία Div'
});
