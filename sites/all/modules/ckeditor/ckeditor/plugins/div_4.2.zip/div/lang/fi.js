﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'fi', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Ohjeistava otsikko',
	cssClassInputLabel: 'Tyylitiedoston luokat',
	edit: 'Muokkaa Diviä',
	inlineStyleInputLabel: 'Sisätyyli',
	langDirLTRLabel: 'Vasemmalta oikealle (LTR)',
	langDirLabel: 'Kielen suunta',
	langDirRTLLabel: 'Oikealta vasemmalle (RTL)',
	languageCodeInputLabel: ' Kielen koodi',
	remove: 'Poista Div',
	styleSelectLabel: 'Tyyli',
	title: 'Luo div-kehikko',
	toolbar: 'Luo div-kehikko'
});
