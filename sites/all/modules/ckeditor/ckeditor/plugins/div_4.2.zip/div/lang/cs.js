﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'cs', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Nápovědní titulek',
	cssClassInputLabel: 'Třídy stylů',
	edit: 'Změnit Div',
	inlineStyleInputLabel: 'Vnitřní styly',
	langDirLTRLabel: 'Zleva doprava (LTR)',
	langDirLabel: 'Směr jazyka',
	langDirRTLLabel: 'Zprava doleva (RTL)',
	languageCodeInputLabel: ' Kód jazyka',
	remove: 'Odstranit Div',
	styleSelectLabel: 'Styly',
	title: 'Vytvořit Div kontejner',
	toolbar: 'Vytvořit Div kontejner'
});
