﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'de', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Tooltip',
	cssClassInputLabel: 'Stylesheet Klasse',
	edit: 'Div bearbeiten',
	inlineStyleInputLabel: 'Inline Stil',
	langDirLTRLabel: 'Links nach Rechs (LTR)',
	langDirLabel: 'Sprache Richtung',
	langDirRTLLabel: 'Rechs nach Links (RTL)',
	languageCodeInputLabel: 'Sprachenkürzel',
	remove: 'Div entfernen',
	styleSelectLabel: 'Style',
	title: 'Div Container erzeugen',
	toolbar: 'Div Container erzeugen'
});
