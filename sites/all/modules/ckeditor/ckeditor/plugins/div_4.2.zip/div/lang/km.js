﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'km', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'ចំណងជើង ប្រឹក្សា',
	cssClassInputLabel: 'Stylesheet Classes',
	edit: 'Edit Div', // MISSING
	inlineStyleInputLabel: 'Inline Style', // MISSING
	langDirLTRLabel: 'ពីឆ្វេងទៅស្តាំ(LTR)',
	langDirLabel: 'ទិសដៅភាសា',
	langDirRTLLabel: 'ពីស្តាំទៅឆ្វេង(RTL)',
	languageCodeInputLabel: ' Language Code', // MISSING
	remove: 'Remove Div', // MISSING
	styleSelectLabel: 'ម៉ូត',
	title: 'Create Div Container', // MISSING
	toolbar: 'Create Div Container' // MISSING
});
