﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'eu', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Izenburua',
	cssClassInputLabel: 'Estilo-orriko Klaseak',
	edit: 'Div-a editatu',
	inlineStyleInputLabel: 'Inline Estiloa',
	langDirLTRLabel: 'Ezkerretik Eskuinera (LTR)',
	langDirLabel: 'Hizkuntzaren Norabidea',
	langDirRTLLabel: 'Eskumatik Ezkerrera (RTL)',
	languageCodeInputLabel: 'Hizkuntza Kodea',
	remove: 'Div-a Kendu',
	styleSelectLabel: 'Estiloa',
	title: 'Div Edukiontzia Sortu',
	toolbar: 'Div Edukiontzia Sortu'
});
