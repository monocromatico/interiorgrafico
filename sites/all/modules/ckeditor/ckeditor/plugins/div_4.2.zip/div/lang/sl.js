﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'sl', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Predlagani naslov',
	cssClassInputLabel: 'Razred stilne predloge',
	edit: 'Uredi Div',
	inlineStyleInputLabel: 'Inline Slog',
	langDirLTRLabel: 'Od leve proti desni (LTR)',
	langDirLabel: 'Smer jezika',
	langDirRTLLabel: 'Od desne proti levi (RTL)',
	languageCodeInputLabel: 'Koda Jezika',
	remove: 'Odstrani Div',
	styleSelectLabel: 'Slog',
	title: 'Ustvari Div Posodo',
	toolbar: 'Ustvari Div Posodo'
});
